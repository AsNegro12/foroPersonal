package com.mx.foroAnime.foroAnime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForoAnimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
